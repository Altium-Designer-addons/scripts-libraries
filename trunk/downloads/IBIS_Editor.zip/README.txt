IBIS Editor v1.0

This Script enables you to override lack of support of Model Selectors in Altium Designer. 

In IBIS standard each pin has defined model (e.g. LVCMOS3V3) that depends on the technology that pin is using. Some devices (like FPGA) allow user to choose model for some or all pins. In IBIS this is done through model selector. Each Model Selector defines list of models that can be used on a pin. Altium does not support this, and if you have model selector defined for a certain pin, Altium will simply pick first model from a list and assign it to a pin. Sometimes this is very bad. It happened to me once that first model on Model Selector list was input model, so Altium would also assign it to I/O pins. If I would set this pin to Output in simulation High value would always be 5V (from Default model). Another problem I've had was that I was not able to simulate pins with ODT values at all.
What this script does is quite simple - it removes model selectors form pin list and assigns user-selected pin models to pins. Script has user interface that asks user to:

1. Import IBIS file,
2. Choose component from list,
3. Assign different pin models to pins,
4. Save IBIS file.

Script does not allow user to save over existing *.ibs file, simply because procedure that is described here actually destroys IBIS file. It does modifies the file in a way that it can be used with Altium, but it removes all Model selector information from selected component, and that kind of IBIS file does not contain correct information any more.

Also, Script sets IBIS version to 3.2, so the file can be used with all versions of Altium.


(Added) Version 2.0

Override for [Submodel] was added to this script.

However, this override is not perfect and it can be used only if you Submodel definition has only POWER Clamp and GND Clamp Tables. Script does not include other submodel keywords.Although this is a limit, most DDR memories I have seen uses only this two tables in submodel definition, so this would work pretty good in those cases.
Information from submodel is added to the model, so the user has to be chareful when to use this kind of IBIS file.

Also, some improvements have been made in using script - You can choose weather to create IBIS file for summer09 or R10. If you choose Summer09 script will comment out some keywords that were not supported in IBIS 3.2, and it will modify version number to 3.2. R10 version will not do this.

Finally, there is global model selector choice. This way you do not have to modify and set each pin - you can do it globally, based on model selector information.




If you have any bug reports, please send me an e-mail to petar.perisin@cadcam.hr, because I would really like to improve the script. This especially means for IBIS in Summer09 and the fact that many lines must be commented out. I might include automatic unsupported line commenting if you let me know about problematic IBIS files.
I am still reading IBIS Specs, and I hope there are some other stuff that can be over-ridden. If you have any info about them please let me know.

Regards,
Petar Perisin
