Obligatory Disclaimer:

----------------------

Cyril Andreatta is furnishing these libraries "as is". I do not provide any warranty of the item whatsoever, whether express, implied, or statutory, including, but not limited to, any warranty of merchantability or fitness for a particular purpose or any warranty that the contents of the item will be error-free. 

In no respect shall I or any other person incur any liability for any damages, including, but limited to, direct, indirect, special, or consequential damages arising out of, resulting from, or any way connected to the use of the item, whether or not based upon warranty, contract, tort, or otherwise; whether or not injury was sustained by persons or property or otherwise; and whether or not loss was sustained from, or arose out of, the results of, the item, or any services that may be provided herein.

Use of these libraries or any elements thereof constitutes acknowledgement and acceptance of the preceeding statements.


*Thanks Ryan for these oh so well phrased words. I just had to adopt it verbatim.

Words from the Author:
----------------------
Every component in our library has its own SchLib and PcbLib file. This might be good or not (discussion and opinions can be directd to cyril{at}andreatta{dot}ch). Even though the quality of the parts are not at the level of Ryan's libs, I decided to share what I've got and hope it might be useful to anybody. The parts should be error free, but it is still your own responsibility to check if it fits your own needs. There are no supplier infos of any kind, that is all handled in our database.
Any comments, improvements or bugs are welcome to the above mentioned email adress.

happy layouting,
Cyril